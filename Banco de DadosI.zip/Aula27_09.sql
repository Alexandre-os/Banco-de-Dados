use BANCO1DS;

create table Peao1(
id int not null primary key auto_increment,
nome varchar (40) not null,
salario decimal (10,2),
nascimento date,
sexo enum ('f','m'),
peso decimal (5,2),
altura decimal(3,2),
nacionalidade varchar(45) default 'Brasil'
)default charset = utf8;

insert into Peao1 (nome, salario, nascimento, sexo, peso, altura, nacionalidade)
values('Ricardo', '2500.45','1985-10=28','m','78.15','1.78','Brasil'),
('José','2500.45','1985-10-29','m','78.15','1.78',default),
('ana','3450.15','1979-12-30','f','56','1.67',default);

select *from Peao1;