-- Os comandos DDL são usados para definir e modificar a estrutura do banco de dados e suas tabelas.
-- Os comandos DML são usados para manipular dados dentro das tabelas.
-- Os comandos DQL são usados para consultar e recuperar dados do banco de dados. 
USE BANCO1DS;

CREATE TABLE funcionarios1234567890123456789012345678 (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100),
    cargo VARCHAR(50),
    salario DECIMAL(10, 2)
);
-- adicionar nome, cargo, salario 
INSERT INTO funcionarios123456789012345678 (nome, cargo, salario) VALUES ('João Silva', 'Analista', 4500.00);
SELECT * FROM funcionarios1234567890123456789012345678;

-- alterar um campo da tabela
ALTER TABLE funcionarios123456789012345678 MODIFY nome TEXT;

-- modificar cargo para funcao
ALTER TABLE funcionarios123456789012345678 CHANGE cargo funcao varchar(50);

-- renomear a tabela para paris
RENAME TABLE funcionarios123456789012345678 TO paris;

-- mostrar estrutura da tabela
DESCRIBE funcionarios123456789012345678;

-- atualizar o campo nome joão silva da tabela para maria
UPDATE clientes
SET nome = 'Maria'
WHERE nome = 'João Silva';

-- O comando DELETE é usado para remover registros (linhas) de uma tabela existente ja O comando DROP é usado para remover completamente objetos do banco de dados, como tabelas, índices ou até mesmo o próprio banco de dados.
DELETE FROM funcionarios123456789012345678 WHERE nome = 'João Silva';
DROP TABLE funcionarios123456789012345678;
