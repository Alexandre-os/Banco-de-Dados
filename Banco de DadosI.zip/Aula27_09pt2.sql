use BANCO1DS;

create table usuaria18181919131312(
id_usuario int primary key auto_increment not null,
nome varchar(45),
senha varchar(45)
);
insert into usuaria18181919131312 (nome, senha) values('Jubileu', md5 ('123456')),
										('Jupiter', md5 ('654321'));
select sha ('123456789');
select sha1('12345');

select *from usuaria18181919131312;
update usuaria18181919 set senha = md5('2020') where id_usuario = '1';
alter table usuaria1818191313
add salario float;
select *from usuaria18181919131312;


