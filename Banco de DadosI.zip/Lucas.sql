-- Usar o banco BANCO1DS
use BANCO1DS;

-- Criar uma tabela
create table Produto12345678910987654321(
idProd int not null primary key,
Nome varchar(50),
Preco float,
Validade date,
Peso double
);

describe Produto12345678910987654321;


insert into Produto12345678910987654321(idProd, Nome, Preco, Validade, Peso)
values(2145,"Ana","125.00","2024/04/26","70");
select idProd, Nome, Validade, Peso from Produto12345678910987654321;


