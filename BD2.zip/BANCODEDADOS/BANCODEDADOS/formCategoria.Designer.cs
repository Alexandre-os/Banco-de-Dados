﻿namespace BANCODEDADOS
{
    partial class formCategoria
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtNome = new TextBox();
            label1 = new Label();
            Cmdgravar = new Button();
            grdCateg = new DataGridView();
            cmdExcluir = new Button();
            ((System.ComponentModel.ISupportInitialize)grdCateg).BeginInit();
            SuspendLayout();
            // 
            // txtNome
            // 
            txtNome.Location = new Point(28, 47);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(500, 23);
            txtNome.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(28, 29);
            label1.Name = "label1";
            label1.Size = new Size(108, 15);
            label1.TabIndex = 1;
            label1.Text = "Nome da categoria";
            // 
            // Cmdgravar
            // 
            Cmdgravar.Location = new Point(427, 76);
            Cmdgravar.Name = "Cmdgravar";
            Cmdgravar.Size = new Size(101, 29);
            Cmdgravar.TabIndex = 2;
            Cmdgravar.Text = "Gravar";
            Cmdgravar.UseVisualStyleBackColor = true;
            Cmdgravar.Click += Cmdgravar_Click;
            // 
            // grdCateg
            // 
            grdCateg.AllowUserToAddRows = false;
            grdCateg.AllowUserToDeleteRows = false;
            grdCateg.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            grdCateg.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            grdCateg.Location = new Point(28, 111);
            grdCateg.Name = "grdCateg";
            grdCateg.ReadOnly = true;
            grdCateg.RowTemplate.Height = 25;
            grdCateg.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            grdCateg.Size = new Size(500, 295);
            grdCateg.TabIndex = 3;
            grdCateg.CellContentClick += grdCateg_CellContentClick;
            // 
            // cmdExcluir
            // 
            cmdExcluir.Location = new Point(427, 412);
            cmdExcluir.Name = "cmdExcluir";
            cmdExcluir.Size = new Size(101, 29);
            cmdExcluir.TabIndex = 4;
            cmdExcluir.Text = "Excluir";
            cmdExcluir.UseVisualStyleBackColor = true;
            cmdExcluir.Click += button1_Click;
            // 
            // formCategoria
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(549, 450);
            Controls.Add(cmdExcluir);
            Controls.Add(grdCateg);
            Controls.Add(Cmdgravar);
            Controls.Add(label1);
            Controls.Add(txtNome);
            Name = "formCategoria";
            Text = "formCategoria";
            Load += formCategoria_Load;
            ((System.ComponentModel.ISupportInitialize)grdCateg).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtNome;
        private Label label1;
        private Button Cmdgravar;
        private DataGridView grdCateg;
        private Button cmdExcluir;
    }
}